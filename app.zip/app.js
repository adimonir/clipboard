let text1 = document.getElementById('myText1').innerHTML;
const copy1 = async () => {
  try {
    await navigator.clipboard.writeText(text1);
  } catch (err) {
    console.error('Failed to copy: ', err);
  }
};

let text2 = document.getElementById('myText2').innerHTML;
const copy2 = async () => {
  try {
    await navigator.clipboard.writeText(text2);
  } catch (err) {
    console.error('Failed to copy: ', err);
  }
};

let text3 = document.getElementById('myText3').innerHTML;
const copy3 = async () => {
  try {
    await navigator.clipboard.writeText(text3);
  } catch (err) {
    console.error('Failed to copy: ', err);
  }
};

let text4 = document.getElementById('myText4').innerHTML;
const copy4 = async () => {
  try {
    await navigator.clipboard.writeText(text4);
  } catch (err) {
    console.error('Failed to copy: ', err);
  }
};

let text5 = document.getElementById('myText5').innerHTML;
const copy5 = async () => {
  try {
    await navigator.clipboard.writeText(text5);
  } catch (err) {
    console.error('Failed to copy: ', err);
  }
};

let text6 = document.getElementById('myText6').innerHTML;
const copy6 = async () => {
  try {
    await navigator.clipboard.writeText(text6);
  } catch (err) {
    console.error('Failed to copy: ', err);
  }
};

let text7 = document.getElementById('myText7').innerHTML;
const copy7 = async () => {
  try {
    await navigator.clipboard.writeText(text7);
  } catch (err) {
    console.error('Failed to copy: ', err);
  }
};

let text8 = document.getElementById('myText8').innerHTML;
const copy8 = async () => {
  try {
    await navigator.clipboard.writeText(text8);
  } catch (err) {
    console.error('Failed to copy: ', err);
  }
};

let text9 = document.getElementById('myText9').innerHTML;
const copy9 = async () => {
  try {
    await navigator.clipboard.writeText(text9);
  } catch (err) {
    console.error('Failed to copy: ', err);
  }
};

let text10 = document.getElementById('myText10').innerHTML;
const copy10 = async () => {
  try {
    await navigator.clipboard.writeText(text10);
  } catch (err) {
    console.error('Failed to copy: ', err);
  }
};

let text11 = document.getElementById('myText11').innerHTML;
const copy11 = async () => {
  try {
    await navigator.clipboard.writeText(text11);
  } catch (err) {
    console.error('Failed to copy: ', err);
  }
};

let text12 = document.getElementById('myText12').innerHTML;
const copy12 = async () => {
  try {
    await navigator.clipboard.writeText(text12);
  } catch (err) {
    console.error('Failed to copy: ', err);
  }
};

let text13 = document.getElementById('myText13').innerHTML;
const copy13 = async () => {
  try {
    await navigator.clipboard.writeText(text13);
  } catch (err) {
    console.error('Failed to copy: ', err);
  }
};

let text14 = document.getElementById('myText14').innerHTML;
const copy14 = async () => {
  try {
    await navigator.clipboard.writeText(text14);
  } catch (err) {
    console.error('Failed to copy: ', err);
  }
};

let text15 = document.getElementById('myText15').innerHTML;
const copy15 = async () => {
  try {
    await navigator.clipboard.writeText(text15);
  } catch (err) {
    console.error('Failed to copy: ', err);
  }
};
